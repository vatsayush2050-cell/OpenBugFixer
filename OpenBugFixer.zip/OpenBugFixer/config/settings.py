"""
Central configuration — reads from environment variables with sane defaults.
Copy .env.example → .env and fill in your keys before running.
"""

import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    # ── AI model ──────────────────────────────────────────────────────────────
    model: str = "openrouter/mistralai/mistral-7b-instruct"
    openrouter_api_key: str = field(default_factory=lambda: os.getenv("OPENROUTER_API_KEY", ""))
    openrouter_base_url: str = "https://openrouter.ai/api/v1"

    # Ollama fallback (used if openrouter_api_key is empty)
    ollama_base_url: str = field(default_factory=lambda: os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("OLLAMA_MODEL", "mistral"))

    # ── GitHub ────────────────────────────────────────────────────────────────
    github_token: str = field(default_factory=lambda: os.getenv("GITHUB_TOKEN", ""))
    github_api_base: str = "https://api.github.com"

    # ── Agent behaviour ───────────────────────────────────────────────────────
    dry_run: bool = False
    max_file_size_bytes: int = 100_000   # skip files larger than this
    max_files_per_fix: int = 5            # patch at most N files per issue
    pr_branch_prefix: str = "bugfix/openbugfixer"

    def use_ollama(self) -> bool:
        """Return True when no OpenRouter key is configured."""
        return not self.openrouter_api_key

    def validate(self):
        if not self.github_token:
            raise EnvironmentError(
                "GITHUB_TOKEN is not set. "
                "Create a fine-grained token with repo + pull-request write scope."
            )
        if self.use_ollama():
            import warnings
            warnings.warn(
                "OPENROUTER_API_KEY not set — falling back to local Ollama. "
                f"Make sure '{self.ollama_model}' is pulled."
            )
