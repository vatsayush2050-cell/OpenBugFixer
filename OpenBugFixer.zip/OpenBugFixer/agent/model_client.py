"""
Unified model client.
  • If OPENROUTER_API_KEY is set  → calls OpenRouter (cloud, any model)
  • Otherwise                     → calls local Ollama
"""

import json
from typing import Optional
import requests
from config.settings import Settings
from utils.logger import get_logger

logger = get_logger(__name__)


class ModelClient:
    def __init__(self, settings: Settings):
        self.settings = settings

    def complete(self, system: str, user: str, max_tokens: int = 2048) -> str:
        """Return the model's text response for a system + user prompt pair."""
        if self.settings.use_ollama():
            return self._ollama(system, user, max_tokens)
        return self._openrouter(system, user, max_tokens)

    # ── OpenRouter ────────────────────────────────────────────────────────────

    def _openrouter(self, system: str, user: str, max_tokens: int) -> str:
        # Strip "openrouter/" prefix if present — OpenRouter expects bare model ids
        model = self.settings.model.removeprefix("openrouter/")
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        resp = requests.post(
            f"{self.settings.openrouter_base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.settings.openrouter_api_key}",
                "HTTP-Referer": "https://github.com/OpenBugFixer",
                "X-Title": "OpenBugFixer Agent",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()

    # ── Ollama ────────────────────────────────────────────────────────────────

    def _ollama(self, system: str, user: str, max_tokens: int) -> str:
        payload = {
            "model": self.settings.ollama_model,
            "stream": False,
            "options": {"num_predict": max_tokens},
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        resp = requests.post(
            f"{self.settings.ollama_base_url}/api/chat",
            json=payload,
            timeout=300,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["message"]["content"].strip()

    # ── JSON helper ───────────────────────────────────────────────────────────

    def complete_json(self, system: str, user: str, max_tokens: int = 2048) -> Optional[dict]:
        """Like complete(), but strips markdown fences and parses JSON."""
        raw = self.complete(system, user, max_tokens)
        # Strip ```json ... ``` or ``` ... ``` wrappers
        cleaned = raw.strip()
        for fence in ("```json", "```"):
            if cleaned.startswith(fence):
                cleaned = cleaned[len(fence):]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Model returned non-JSON; raw output:\n%s", raw[:500])
            return None
