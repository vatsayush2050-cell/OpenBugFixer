"""
Analyses a GitHub issue and decides:
  1. Is this issue fixable by an automated agent?
  2. Which files are likely relevant?
  3. What kind of fix is needed (bug, docs, test, refactor)?
"""

from dataclasses import dataclass, field
from typing import Optional
from agent.model_client import ModelClient
from utils.logger import get_logger

logger = get_logger(__name__)

SYSTEM_PROMPT = """You are a senior software engineer triaging GitHub issues for an automated bug-fixing agent.
Your job is to decide whether an issue can be fixed autonomously and, if so, identify the relevant files.

Always respond with ONLY valid JSON — no markdown, no explanation outside the JSON block."""

TRIAGE_TEMPLATE = """Repository: {repo}
Issue #{number}: {title}

Issue body:
{body}

Recent comments:
{comments}

Repository file tree (top level):
{file_tree}

Task: Analyse the issue and respond with JSON in exactly this shape:
{{
  "fixable": true | false,
  "confidence": 0.0–1.0,
  "fix_type": "bug" | "docs" | "test" | "refactor" | "unknown",
  "reason": "<one sentence explaining why fixable or not>",
  "relevant_files": ["path/to/file1.py", "path/to/file2.py"],
  "fix_summary": "<one sentence describing the fix needed>"
}}

Rules:
- fixable = true only if the issue describes a concrete, localised problem in code or docs.
- Vague feature requests, design discussions, or questions → fixable = false.
- relevant_files must be real paths visible in the file tree above.
- Keep relevant_files ≤ 5 entries.
"""


@dataclass
class IssueAnalysis:
    fixable: bool
    confidence: float
    fix_type: str
    reason: str
    relevant_files: list[str] = field(default_factory=list)
    fix_summary: str = ""


class IssueAnalyzer:
    def __init__(self, model_client: ModelClient):
        self.model = model_client

    def analyze(
        self,
        repo: str,
        issue: dict,
        comments: list[dict],
        file_tree: list[str],
    ) -> IssueAnalysis:
        number = issue["number"]
        title = issue["title"]
        body = (issue.get("body") or "").strip()[:3000]

        comment_text = "\n".join(
            f"- {c['user']['login']}: {c['body'][:300]}" for c in comments[:5]
        )

        tree_text = "\n".join(file_tree[:80])

        prompt = TRIAGE_TEMPLATE.format(
            repo=repo,
            number=number,
            title=title,
            body=body,
            comments=comment_text or "(none)",
            file_tree=tree_text or "(unavailable)",
        )

        logger.info(f"Analysing issue #{number}: {title}")
        result = self.model.complete_json(SYSTEM_PROMPT, prompt, max_tokens=512)

        if not result:
            return IssueAnalysis(
                fixable=False,
                confidence=0.0,
                fix_type="unknown",
                reason="Model did not return valid JSON",
            )

        return IssueAnalysis(
            fixable=bool(result.get("fixable", False)),
            confidence=float(result.get("confidence", 0.0)),
            fix_type=result.get("fix_type", "unknown"),
            reason=result.get("reason", ""),
            relevant_files=result.get("relevant_files", []),
            fix_summary=result.get("fix_summary", ""),
        )
