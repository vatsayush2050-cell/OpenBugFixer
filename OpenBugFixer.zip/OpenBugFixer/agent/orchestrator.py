"""
BugFixerOrchestrator — the top-level agent loop.

Flow:
  1. Fetch open issues from the repo
  2. Build a file tree for context
  3. Triage each issue (IssueAnalyzer)
  4. Pick the highest-confidence fixable issue
  5. Generate the fix (CodeFixer)
  6. Commit and open a PR (PRBuilder)
"""

from typing import Optional
from agent.model_client import ModelClient
from agent.issue_analyzer import IssueAnalyzer
from agent.code_fixer import CodeFixer
from agent.pr_builder import PRBuilder
from github.client import GitHubClient
from config.settings import Settings
from utils.logger import get_logger

logger = get_logger(__name__)


class BugFixerOrchestrator:
    def __init__(self, settings: Settings):
        settings.validate()
        self.settings = settings
        self.github = GitHubClient(settings.github_token, settings.github_api_base)
        self.model = ModelClient(settings)
        self.analyzer = IssueAnalyzer(self.model)
        self.fixer = CodeFixer(self.model, self.github, settings)
        self.pr_builder = PRBuilder(self.github, settings)

    def run(
        self,
        repo_full_name: str,
        issue_number: Optional[int] = None,
        max_issues: int = 5,
    ) -> Optional[str]:
        logger.info(f"Repository: {repo_full_name}")

        # ── 1. Gather repo context ────────────────────────────────────────────
        try:
            repo_info = self.github.get_repo(repo_full_name)
        except Exception as e:
            logger.error(f"Cannot access repository: {e}")
            return None

        default_branch = repo_info["default_branch"]
        logger.info(f"Default branch: {default_branch}")

        file_tree = self._build_file_tree(repo_full_name)

        # ── 2. Collect issues ─────────────────────────────────────────────────
        if issue_number:
            issues = [self.github.get_issue(repo_full_name, issue_number)]
            logger.info(f"Targeting specific issue #{issue_number}")
        else:
            issues = self.github.list_issues(repo_full_name, limit=max_issues)
            logger.info(f"Fetched {len(issues)} open issues")

        if not issues:
            logger.warning("No open issues found.")
            return None

        # ── 3. Triage ─────────────────────────────────────────────────────────
        candidates = []
        for issue in issues:
            comments = self.github.get_issue_comments(repo_full_name, issue["number"])
            analysis = self.analyzer.analyze(repo_full_name, issue, comments, file_tree)
            logger.info(
                f"  Issue #{issue['number']} — fixable={analysis.fixable} "
                f"conf={analysis.confidence:.2f} type={analysis.fix_type} — {analysis.reason}"
            )
            if analysis.fixable and analysis.confidence >= 0.5:
                candidates.append((issue, analysis))

        if not candidates:
            logger.warning("No fixable issues found with sufficient confidence.")
            return None

        # Pick the highest-confidence candidate
        candidates.sort(key=lambda x: x[1].confidence, reverse=True)
        issue, analysis = candidates[0]
        logger.info(
            f"Selected issue #{issue['number']}: {issue['title']} "
            f"(confidence {analysis.confidence:.0%})"
        )

        # ── 4. Generate fix ───────────────────────────────────────────────────
        fix_result = self.fixer.fix(repo_full_name, issue, analysis, default_branch)
        if not fix_result.success:
            logger.error("Fix generation failed.")
            return None

        logger.info(f"Fix generated — {len(fix_result.patches)} file(s) changed")
        for p in fix_result.patches:
            logger.info(f"  • {p.path}: {p.change_description}")

        # ── 5. Open PR ────────────────────────────────────────────────────────
        pr_url = self.pr_builder.build(
            repo_full_name,
            issue["number"],
            fix_result,
            default_branch,
        )

        if pr_url:
            return f"PR opened: {pr_url}"
        return None

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_file_tree(self, repo: str, max_depth: int = 2) -> list[str]:
        """Return a flat list of file paths up to `max_depth` levels deep."""
        paths: list[str] = []

        def _recurse(directory: str, depth: int):
            if depth > max_depth or len(paths) > 200:
                return
            entries = self.github.list_directory(repo, directory)
            for entry in entries:
                if entry["type"] == "file":
                    paths.append(entry["path"])
                elif entry["type"] == "dir" and depth < max_depth:
                    _recurse(entry["path"], depth + 1)

        try:
            _recurse("", 0)
        except Exception as e:
            logger.warning(f"Could not build file tree: {e}")

        return paths
