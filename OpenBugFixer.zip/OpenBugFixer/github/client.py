"""
Thin wrapper around the GitHub REST API.
Handles pagination, rate-limit detection, and branch/PR creation.
"""

import base64
import time
from typing import Optional
import requests
from utils.logger import get_logger

logger = get_logger(__name__)


class GitHubClient:
    def __init__(self, token: str, base_url: str = "https://api.github.com"):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }
        )

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _get(self, path: str, params: dict = None) -> dict | list:
        url = f"{self.base_url}{path}"
        resp = self.session.get(url, params=params or {})
        self._check(resp)
        return resp.json()

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{self.base_url}{path}"
        resp = self.session.post(url, json=payload)
        self._check(resp)
        return resp.json()

    def _patch(self, path: str, payload: dict) -> dict:
        url = f"{self.base_url}{path}"
        resp = self.session.patch(url, json=payload)
        self._check(resp)
        return resp.json()

    def _put(self, path: str, payload: dict) -> dict:
        url = f"{self.base_url}{path}"
        resp = self.session.put(url, json=payload)
        self._check(resp)
        return resp.json()

    @staticmethod
    def _check(resp: requests.Response):
        if resp.status_code == 403 and "rate limit" in resp.text.lower():
            reset = int(resp.headers.get("X-RateLimit-Reset", time.time() + 60))
            wait = max(reset - int(time.time()), 1)
            logger.warning(f"Rate limited — sleeping {wait}s")
            time.sleep(wait)
            return
        resp.raise_for_status()

    # ── Repo info ─────────────────────────────────────────────────────────────

    def get_repo(self, full_name: str) -> dict:
        return self._get(f"/repos/{full_name}")

    def get_default_branch(self, full_name: str) -> str:
        repo = self.get_repo(full_name)
        return repo["default_branch"]

    # ── Issues ────────────────────────────────────────────────────────────────

    def list_issues(self, full_name: str, state: str = "open", limit: int = 20) -> list[dict]:
        issues = self._get(
            f"/repos/{full_name}/issues",
            params={"state": state, "per_page": min(limit, 100), "sort": "created"},
        )
        # Filter out pull requests (GitHub returns PRs in issues endpoint)
        return [i for i in issues if "pull_request" not in i][:limit]

    def get_issue(self, full_name: str, number: int) -> dict:
        return self._get(f"/repos/{full_name}/issues/{number}")

    def get_issue_comments(self, full_name: str, number: int) -> list[dict]:
        return self._get(f"/repos/{full_name}/issues/{number}/comments")

    # ── File content ──────────────────────────────────────────────────────────

    def get_file_content(self, full_name: str, path: str, ref: str = None) -> Optional[tuple[str, str]]:
        """Returns (decoded_content, sha) or None if file not found / too large."""
        params = {}
        if ref:
            params["ref"] = ref
        try:
            data = self._get(f"/repos/{full_name}/contents/{path}", params=params)
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise
        if isinstance(data, list):
            return None  # it's a directory
        if data.get("encoding") != "base64":
            return None
        content = base64.b64decode(data["content"]).decode("utf-8", errors="replace")
        return content, data["sha"]

    def list_directory(self, full_name: str, path: str = "", ref: str = None) -> list[dict]:
        params = {}
        if ref:
            params["ref"] = ref
        try:
            data = self._get(f"/repos/{full_name}/contents/{path}", params=params)
        except requests.HTTPError:
            return []
        return data if isinstance(data, list) else []

    # ── Branches ─────────────────────────────────────────────────────────────

    def get_branch_sha(self, full_name: str, branch: str) -> str:
        data = self._get(f"/repos/{full_name}/git/ref/heads/{branch}")
        return data["object"]["sha"]

    def create_branch(self, full_name: str, new_branch: str, from_sha: str) -> dict:
        return self._post(
            f"/repos/{full_name}/git/refs",
            {"ref": f"refs/heads/{new_branch}", "sha": from_sha},
        )

    # ── Commits / file updates ────────────────────────────────────────────────

    def update_file(
        self,
        full_name: str,
        path: str,
        message: str,
        content: str,
        sha: str,
        branch: str,
    ) -> dict:
        encoded = base64.b64encode(content.encode()).decode()
        return self._put(
            f"/repos/{full_name}/contents/{path}",
            {
                "message": message,
                "content": encoded,
                "sha": sha,
                "branch": branch,
            },
        )

    def create_file(
        self,
        full_name: str,
        path: str,
        message: str,
        content: str,
        branch: str,
    ) -> dict:
        encoded = base64.b64encode(content.encode()).decode()
        return self._put(
            f"/repos/{full_name}/contents/{path}",
            {"message": message, "content": encoded, "branch": branch},
        )

    # ── Pull Requests ─────────────────────────────────────────────────────────

    def create_pull_request(
        self,
        full_name: str,
        title: str,
        body: str,
        head: str,
        base: str,
    ) -> dict:
        return self._post(
            f"/repos/{full_name}/pulls",
            {
                "title": title,
                "body": body,
                "head": head,
                "base": base,
                "maintainer_can_modify": True,
            },
        )

    def add_pr_labels(self, full_name: str, pr_number: int, labels: list[str]) -> dict:
        return self._post(
            f"/repos/{full_name}/issues/{pr_number}/labels",
            {"labels": labels},
        )
